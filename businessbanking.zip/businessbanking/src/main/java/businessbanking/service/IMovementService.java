package businessbanking.service;

import businessbanking.model.Movement;

public interface IMovementService extends ICRUD<Movement, String>{
}
